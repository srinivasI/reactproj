import React, {useState} from "react";
const Hookex = () => {
    const [value, setValue] = useState(10);
    return (
        <div>
            <p>{value}</p>
            <button onClick={() => setValue((value + 1))}>Increment Value</button>
        </div>
    );
};
export default Hookex;