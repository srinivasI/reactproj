import logo from './logo.svg';
import './App.css';
import First from './First';

export default function App(props) {
  return (
    <>
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h3>Hello Srini</h3>
       <h3>{props.mysal}</h3>
        <First cname="ANgular" mysal="90000"></First>
        <First />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <h3>How are you?</h3>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </>
  );
}


